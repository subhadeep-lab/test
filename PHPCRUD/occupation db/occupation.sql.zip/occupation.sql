-- phpMyAdmin SQL Dump
-- version 4.9.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 12, 2020 at 04:53 PM
-- Server version: 10.4.8-MariaDB
-- PHP Version: 7.3.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `occupation`
--

-- --------------------------------------------------------

--
-- Table structure for table `doctor_personnel`
--

CREATE TABLE `doctor_personnel` (
  `personnel_id` int(32) NOT NULL,
  `doctor_name` varchar(32) NOT NULL,
  `doctor_phone` int(32) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `doctor_personnel`
--

INSERT INTO `doctor_personnel` (`personnel_id`, `doctor_name`, `doctor_phone`) VALUES
(1, '', 0),
(2, 'a77', 223366),
(3, '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `personnel`
--

CREATE TABLE `personnel` (
  `personnel_id` int(32) NOT NULL,
  `username` varchar(32) NOT NULL,
  `email` varchar(32) NOT NULL,
  `phone_number` int(32) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `personnel`
--

INSERT INTO `personnel` (`personnel_id`, `username`, `email`, `phone_number`) VALUES
(1, 'subhadeep', 'subhadeep.412@gmail.com', 66554488),
(2, 'kamal', 'kamal.009@gmail.com', 7788999),
(3, 'raman', 'kkk@gmail.com', 225588);

-- --------------------------------------------------------

--
-- Table structure for table `pilot_personnel`
--

CREATE TABLE `pilot_personnel` (
  `personnel_id` int(32) NOT NULL,
  `pilot_name` varchar(32) NOT NULL,
  `pilot_phone` int(32) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `pilot_personnel`
--

INSERT INTO `pilot_personnel` (`personnel_id`, `pilot_name`, `pilot_phone`) VALUES
(1, 'su19', 78956666),
(2, '', 0),
(3, 'p77', 425698);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `doctor_personnel`
--
ALTER TABLE `doctor_personnel`
  ADD PRIMARY KEY (`personnel_id`);

--
-- Indexes for table `personnel`
--
ALTER TABLE `personnel`
  ADD PRIMARY KEY (`personnel_id`);

--
-- Indexes for table `pilot_personnel`
--
ALTER TABLE `pilot_personnel`
  ADD PRIMARY KEY (`personnel_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `doctor_personnel`
--
ALTER TABLE `doctor_personnel`
  MODIFY `personnel_id` int(32) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `personnel`
--
ALTER TABLE `personnel`
  MODIFY `personnel_id` int(32) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `pilot_personnel`
--
ALTER TABLE `pilot_personnel`
  MODIFY `personnel_id` int(32) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `doctor_personnel`
--
ALTER TABLE `doctor_personnel`
  ADD CONSTRAINT `doctor_personnel_ibfk_1` FOREIGN KEY (`personnel_id`) REFERENCES `personnel` (`personnel_id`);

--
-- Constraints for table `pilot_personnel`
--
ALTER TABLE `pilot_personnel`
  ADD CONSTRAINT `pilot_personnel_ibfk_1` FOREIGN KEY (`personnel_id`) REFERENCES `personnel` (`personnel_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
