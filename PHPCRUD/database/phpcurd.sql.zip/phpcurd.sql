-- phpMyAdmin SQL Dump
-- version 4.9.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 11, 2020 at 08:56 AM
-- Server version: 10.4.8-MariaDB
-- PHP Version: 7.3.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `phpcurd`
--

-- --------------------------------------------------------

--
-- Table structure for table `category_details`
--

CREATE TABLE `category_details` (
  `id` int(32) NOT NULL,
  `Itemname` varchar(32) NOT NULL,
  `colour` varchar(32) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `category_details`
--

INSERT INTO `category_details` (`id`, `Itemname`, `colour`) VALUES
(3, 'subha', 'yellow'),
(6, 'item4', 'yellow'),
(27, 'item9', 'black');

-- --------------------------------------------------------

--
-- Table structure for table `doctor_personnel`
--

CREATE TABLE `doctor_personnel` (
  `id` int(32) NOT NULL,
  `username` varchar(32) NOT NULL,
  `email` varchar(32) NOT NULL,
  `personnel_id` int(32) NOT NULL,
  `occupation` varchar(11) NOT NULL,
  `doctor_id` int(32) NOT NULL,
  `doctor_name` varchar(32) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `doctor_personnel`
--

INSERT INTO `doctor_personnel` (`id`, `username`, `email`, `personnel_id`, `occupation`, `doctor_id`, `doctor_name`) VALUES
(3, 'avik', 'avik@gmail.com', 112211, 'doctor', 23565, 'a77');

-- --------------------------------------------------------

--
-- Table structure for table `pilot_personnel`
--

CREATE TABLE `pilot_personnel` (
  `id` int(11) NOT NULL,
  `username` varchar(32) NOT NULL,
  `email` varchar(32) NOT NULL,
  `personnel_id` int(11) NOT NULL,
  `occupation` varchar(32) NOT NULL,
  `pilot_id` int(32) NOT NULL,
  `pilot_name` varchar(32) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `pilot_personnel`
--

INSERT INTO `pilot_personnel` (`id`, `username`, `email`, `personnel_id`, `occupation`, `pilot_id`, `pilot_name`) VALUES
(3, 'subhadeep', 'subhadeep.412@gmail.com', 112211, 'pilot', 124563, 'su77');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `category_details`
--
ALTER TABLE `category_details`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `doctor_personnel`
--
ALTER TABLE `doctor_personnel`
  ADD PRIMARY KEY (`id`,`personnel_id`);

--
-- Indexes for table `pilot_personnel`
--
ALTER TABLE `pilot_personnel`
  ADD PRIMARY KEY (`id`,`personnel_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `category_details`
--
ALTER TABLE `category_details`
  MODIFY `id` int(32) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=39;

--
-- AUTO_INCREMENT for table `doctor_personnel`
--
ALTER TABLE `doctor_personnel`
  MODIFY `id` int(32) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `pilot_personnel`
--
ALTER TABLE `pilot_personnel`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
